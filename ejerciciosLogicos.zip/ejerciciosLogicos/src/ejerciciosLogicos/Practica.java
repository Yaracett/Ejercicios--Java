package ejerciciosLogicos;

public class Practica {

	public static void main(String[] args) {
	}
}
